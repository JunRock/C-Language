﻿
// ImagePro_20194016_1Doc.cpp: CImagePro201940161Doc 클래스의 구현
//

#include "stdafx.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "ImagePro_20194016_1.h"
#endif

#include "ImagePro_20194016_1Doc.h"

#include <propkey.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CImagePro201940161Doc

IMPLEMENT_DYNCREATE(CImagePro201940161Doc, CDocument)

BEGIN_MESSAGE_MAP(CImagePro201940161Doc, CDocument)
END_MESSAGE_MAP()


// CImagePro201940161Doc 생성/소멸

CImagePro201940161Doc::CImagePro201940161Doc() noexcept
{
	inputImg = NULL;
	inputImg2 = NULL;
	resultImg = NULL;

}

CImagePro201940161Doc::~CImagePro201940161Doc()
{
}

BOOL CImagePro201940161Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: 여기에 재초기화 코드를 추가합니다.
	// SDI 문서는 이 문서를 다시 사용합니다.

	return TRUE;
}




// CImagePro201940161Doc serialization

void CImagePro201940161Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		
	}
	else
	{
		LoadImageFile(ar);
	}
}

#ifdef SHARED_HANDLERS

// 축소판 그림을 지원합니다.
void CImagePro201940161Doc::OnDrawThumbnail(CDC& dc, LPRECT lprcBounds)
{
	// 문서의 데이터를 그리려면 이 코드를 수정하십시오.
	dc.FillSolidRect(lprcBounds, RGB(255, 255, 255));

	CString strText = _T("TODO: implement thumbnail drawing here");
	LOGFONT lf;

	CFont* pDefaultGUIFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	pDefaultGUIFont->GetLogFont(&lf);
	lf.lfHeight = 36;

	CFont fontDraw;
	fontDraw.CreateFontIndirect(&lf);

	CFont* pOldFont = dc.SelectObject(&fontDraw);
	dc.DrawText(strText, lprcBounds, DT_CENTER | DT_WORDBREAK);
	dc.SelectObject(pOldFont);
}

// 검색 처리기를 지원합니다.
void CImagePro201940161Doc::InitializeSearchContent()
{
	CString strSearchContent;
	// 문서의 데이터에서 검색 콘텐츠를 설정합니다.
	// 콘텐츠 부분은 ";"로 구분되어야 합니다.

	// 예: strSearchContent = _T("point;rectangle;circle;ole object;");
	SetSearchContent(strSearchContent);
}

void CImagePro201940161Doc::SetSearchContent(const CString& value)
{
	if (value.IsEmpty())
	{
		RemoveChunk(PKEY_Search_Contents.fmtid, PKEY_Search_Contents.pid);
	}
	else
	{
		CMFCFilterChunkValueImpl *pChunk = nullptr;
		ATLTRY(pChunk = new CMFCFilterChunkValueImpl);
		if (pChunk != nullptr)
		{
			pChunk->SetTextValue(PKEY_Search_Contents, value, CHUNK_TEXT);
			SetChunkValue(pChunk);
		}
	}
}

#endif // SHARED_HANDLERS

// CImagePro201940161Doc 진단

#ifdef _DEBUG
void CImagePro201940161Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CImagePro201940161Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CImagePro201940161Doc 명령


void CImagePro201940161Doc::PixelAdd()
{
	int value = 0;

	for(int x=0;x<256;x++)
		for (int y = 0; y < 256; y++) {
			value = inputImg[x][y] + 100;
			if (value > 255)resultImg[x][y] = 255;
			else resultImg[x][y] = value;
		}
}


void CImagePro201940161Doc::PixelHistoEq()
{
	int x, y, i, k; 
	int acc_hist = 0;   
	float N = 256 * 256;   
	int hist[256], sum[256]; 

	for (k = 0; k < 256; k++) hist[k] = 0;

	for (y = 0; y < 256; y++)
		for (x = 0; x < 256; x++) {
			k = inputImg[y][x];
			hist[k] = hist[k] + 1;
		}

	for (i = 0; i < 256; i++) {
		acc_hist = acc_hist + hist[i];
		sum[i] = acc_hist; 
	}

	for (y = 0; y < 256; y++)
		for (x = 0; x < 256; x++) {
			k = inputImg[y][x]; 
			resultImg[y][x] = sum[k] / N * 255;
		}
}


void CImagePro201940161Doc::PixelTwoImageAdd()
{
	int value = 0;
	LoadTwoImages();
	for (int y = 0; y < 256; y++) for (int x = 0; x < 256; x++) {
		value = inputImg[y][x] + inputImg2[y][x];
		if (value > 255) resultImg[y][x] = 255;
		else resultImg[y][x] = value;
	}
}


void CImagePro201940161Doc::LoadTwoImages()
{
	CFile file; 
	CFileDialog dlg(TRUE);

	AfxMessageBox("Select the First Image");

	if (dlg.DoModal() == IDOK) { 
		file.Open(dlg.GetPathName(), CFile::modeRead);  
		file.Read(inputImg, 256*256);  
	    file.Close();               
	}

	AfxMessageBox("Select the Second Image");

	if (dlg.DoModal() == IDOK) {
		file.Open(dlg.GetPathName(), CFile::modeRead);
		file.Read(inputImg2, 256 * 256);
		file.Close();
	}
}


void CImagePro201940161Doc::LoadImageFile(CArchive &ar)
{
	int i, maxValue;
	CStringtype, buf; 
	CFile*fp = ar.GetFile();
	CStringfname = fp->GetFilePath();

	if (strcmp(strrchr(fname, '.'), ".ppm") == 0 || strcmp(strrchr(fname, '.'), ".PPM") == 0 ||
		strcmp(strrchr(fname, '.'), ".PGM") == 0 || strcmp(strrchr(fname, '.'), ".pgm") == 0)

	{
		ar.ReadString(type);
		do { ar.ReadString(buf); 
		} while (buf[0] == '#');
		sscanf_s(buf, "%d %d", &imageWidth, &imageHeight);

		do { ar.ReadString(buf); 
		} while (buf[0] == '#'); 
		sscanf_s(buf, "%d", &maxValue);

		if (strcmp(type, "P5") == 0) depth = 1;
		else depth = 3;
	}
	else if (strcmp(strrchr(fname, '.'), ".raw") == 0 ||
		strcmp(strrchr(fname, '.'), ".RAW") == 0) {
}
